# package taskcat in lambda
pip install taskcat -t lambda_layers/python/lib/python3.8/site-packages/
zip -r taskcat_lambda_layer.zip *
